package com.streamvault.android.tv

import com.streamvault.domain.model.MediaItem
import com.streamvault.domain.model.WatchProgress
import com.streamvault.domain.model.WatchlistItem

fun WatchProgress.toMediaItemOrNull(): MediaItem? {
    val tmdbId = mediaId.toIntOrNull()
    return MediaItem(
        id = mediaId,
        tmdbId = tmdbId,
        imdbId = null,
        type = mediaType,
        title = title,
        year = null,
        overview = null,
        posterUrl = posterUrl,
        backdropUrl = backdropUrl,
        rating = null,
    )
}

fun WatchlistItem.toMediaItem(): MediaItem {
    return MediaItem(
        id = mediaId,
        tmdbId = tmdbId,
        imdbId = imdbId,
        type = mediaType,
        title = title,
        year = year,
        overview = null,
        posterUrl = posterUrl,
        backdropUrl = backdropUrl,
        rating = rating,
    )
}

